These files contains the needed configurations for Deepsea and Doom Builder to create and edit the levels for the Doom64 TC. 

Doom64.opt is for Deepsea and D64_Builder.cfg is for Doom Builder



Deepsea: Instructions
=========================
Go to options select option menu, and select user opt file. Load doom64.opt and restart deepsea.


Doom Builder: Instructions
=========================
Select new map, and under games, select Doom64 TC. Load doom64_abstin.wad as your iwad.
Ignore the messages saying that it is missing the Doom2 patches. This won't effect anything.



Happy mapping!

-kaiser
